"use client";

import React, { useState } from "react";
import type { CodeNode } from "../types";

/**
 * Renders raw, pre-formatted code. Deliberately has no syntax-highlighting
 * dependency -- drop in your highlighter of choice (Shiki, Prism, etc.) by
 * replacing the `<code>` body; the AST already carries `node.lang`.
 */
export function CodeBlock({ node }: { node: CodeNode }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(node.value);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // Clipboard API unavailable (e.g. insecure context) -- ignore silently.
    }
  };

  return (
    <div className="group relative my-6 overflow-hidden rounded-lg border border-slate-800 bg-slate-950">
      <div className="flex items-center justify-between border-b border-slate-800 px-4 py-2">
        <span className="font-mono text-xs uppercase tracking-wide text-slate-400">
          {node.lang || "text"}
        </span>
        <button
          type="button"
          onClick={handleCopy}
          className="rounded px-2 py-1 text-xs font-medium text-slate-400 transition-colors hover:bg-slate-800 hover:text-slate-100"
        >
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
      <pre className="overflow-x-auto p-4 text-sm leading-6">
        <code className="font-mono text-slate-100">{node.value}</code>
      </pre>
    </div>
  );
}
